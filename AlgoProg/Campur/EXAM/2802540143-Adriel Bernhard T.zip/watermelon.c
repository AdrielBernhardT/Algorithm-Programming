
#include <stdio.h>
int main(){
    int besar;
    scanf("%d", &besar);
    besar/=2;
    if (besar%2 == 0)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
    return 0;
}