#include <stdio.h>


int main(){
    char string[105];
    scanf("%[^\n]", &string); getchar();
    string[0] = '2';
    string[1] = '0';
    string[2] = '1';
    string[3] = '8';
    printf("%s\n", string);
    
    return 0;
}